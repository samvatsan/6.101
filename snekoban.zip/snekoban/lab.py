"""
6.1010 Lab 4: Sam Vinu-Srivatsan
Snekoban Game
"""

# import json
# import typing

# NO ADDITIONAL IMPORTS!


direction_vector = {
    "up": (-1, 0),
    "down": (+1, 0),
    "left": (0, -1),
    "right": (0, +1),
}


def make_new_game(level_description):
    """
    Given a description of a game state, create and return a game
    representation of your choice.

    The given description is a list of lists of lists of strs, representing the
    locations of the objects on the board (as described in the lab writeup).

    For example, a valid level_description is:

    [
        [[], ['wall'], ['computer']],
        [['target', 'player'], ['computer'], ['target']],
    ]

    The exact choice of representation is up to you; but note that what you
    return will be used as input to the other functions.
    """
    num_rows = len(level_description)
    num_cols = len(level_description[0])
    game = {"wall":set(),"target":set(),
            "computer":set(),"player":(),"size":(num_rows,num_cols)}
    # loop through each list inside the outer game lst - each of these is a row
    for row in range(num_rows): # inner nested list
        for col in range(num_cols): # innermost nested list
            # store all the coordinates where each of the objects can be found
            value = level_description[row][col]
            if "wall" in value: # at each (row,col)
                game["wall"].add((row,col))
            if "target" in value:
                game["target"].add((row,col))
            # note that player can only be in 1 spot at a time, tuple instead of set
            if "player" in value:
                game["player"] = (row,col)
            if "computer" in value:
                game["computer"].add((row,col))
    return game

def victory_check(game):
    """
    Given a game representation (of the form returned from make_new_game),
    return a Boolean: True if the given game satisfies the victory condition,
    and False otherwise.
    """
    # victory condition is when all computers are on all targets
    # if the "target" and "computer" key set are the same

    if not game["target"]: # if set of targets is empty - falsy value
        return False
    elif game["target"] == game["computer"]: # for nonempty target list
        return True
    return False

def step_game(game, direction):
    """
    Given a game representation (of the form returned from make_new_game),
    return a new game representation (of that same form), representing the
    updated game after running one step of the game.  The user's input is given
    by direction, which is one of the following:
        {'up', 'down', 'left', 'right'}.

    This function should not mutate its input.
    """
    new_game = game.copy()
    # shallow dict copy is fine for "target" and "wall" since they don't change
    # only "player" and "computers" need to be recopied at the set level
    new_game["player"] = (game["player"][0],game["player"][1])
    new_game["computer"] = game["computer"].copy()

    # get player position coordinates
    player_x,player_y = game["player"]
    change_x,change_y = direction_vector[direction]
    future_position = (player_x+change_x,player_y+change_y)
    # apply x and y change to future position
    future_computer_position = (player_x+2*change_x,player_y+2*change_y)
    # if there is a wall at future position
    if future_position in new_game["wall"]:
        return new_game # no changes
    # if there is a computer at future position
    if future_position in new_game["computer"]:
        # if there is a computer at future_computer_position
        if future_computer_position in new_game["computer"]:
            return new_game # no change, can't push 2 computers at once
        elif future_computer_position in new_game["wall"]:
            return new_game # no change, can't push computer into wall
        # if there is a wall at future_computer_position
        else: # free for computer
            # push the computer and take its spot
            new_game["computer"].remove(future_position)
            new_game["computer"].add(future_computer_position)
            new_game["player"] = (player_x+change_x,player_y+change_y)
        return new_game
    else: # no wall and no computer
        # replace player position with new tuple in new_game
        new_game["player"] = (player_x+change_x,player_y+change_y)
        return new_game


def dump_game(game):
    """
    Given a game representation (of the form returned from make_new_game),
    convert it back into a level description that would be a suitable input to
    make_new_game (a list of lists of lists of strings).

    This function is used by the GUI and the tests to see what your game
    implementation has done, and it can also serve as a rudimentary way to
    print out the current state of your game for testing and debugging on your
    own.
    """
    rows,cols = game["size"]
    # nested list comprehension to populate 3 layers of lists
    dump = [[[] for _ in range(cols)] for _ in range(rows)]
    for obj in game: # wall,computer,target but skip player,size
        if obj == "size":
            continue
        elif obj == "player":
            row,col = game[obj]
            dump[row][col].append(obj)
        else:
            for row,col in game[obj]:
                dump[row][col].append(obj)
    return dump


def relevant(game):
    """
    Given a full game representation (dictionary), extract
    only the relevant pieces that change in each timestep.
    Returns a tuple of tuple (player position), frozenset (computer positions)
    """
    player_pos = game["player"] # tuple
    computer_pos = frozenset(game["computer"])
    return (player_pos,computer_pos)

def get_neighbors(game):
    """
    Take in a dictionary game state and return all neighboring game states that can
    be achieved by moving 1 step in each direction. Return these in a list
    (a set cannot store an unhashable type dictionary).
    """
    neighbor_states = []
    for direction in direction_vector:
        state = step_game(game,direction)
        neighbor_states.append(state)
        # adds only if unique portion of game state and move/direction
    return neighbor_states

def find_path(neighbors_function,start,goal_test):
    """
    Find the shortest path from start state to end state defined by goal_test
    by traversing neighboring game states.
    Returns tuple of dicts (path of states).
    """
    if goal_test(start): # end condition met at start
        return (start,)

    agenda = [(start,)] #  to traverse next
    # agenda list: stores tuple paths of dicts
    hashable_start = relevant(start)
    visited = {hashable_start} # traversed already
    # visited set: stores unique, hashable, only relevant varying info

    while agenda: # as long as there are still states to explore
        this_path = agenda.pop(0)
        terminal_state = this_path[-1]
        # explore all neighbor game states
        for neighbor in neighbors_function(terminal_state):
            if relevant(neighbor) not in visited: # don't re-explore same paths
                new_path = this_path + (neighbor,)
                if goal_test(neighbor):
                    # call goal_test on full dict game setup
                    return new_path
                agenda.append(new_path)
                visited.add(relevant(neighbor))
    return None


def solve_puzzle(game):
    """
    Given a game representation (of the form returned from make_new_game), find
    a solution.

    Return a list of strings representing the shortest sequence of moves ("up",
    "down", "left", and "right") needed to reach the victory condition.

    If the given level cannot be solved, return None.
    """
    # find_path returns list of full game states - shortest path from bfs
    path = find_path(get_neighbors,game,victory_check)
    # unsolvable level
    if path is None:
        return None

    player_positions = [] # all player positions
    for state in path:
        player_positions.append(state["player"])
    # convert from game nodes to edges (game states to moves)
    moves = []
    for index in range(1,len(player_positions)):
        x,y = player_positions[index-1]
        next_x,next_y = player_positions[index]
        (dx,dy) = next_x-x,next_y-y
        for direction in direction_vector:
            if direction_vector[direction] == (dx,dy):
                moves.append(direction)
    return moves


if __name__ == "__main__":
    pass
