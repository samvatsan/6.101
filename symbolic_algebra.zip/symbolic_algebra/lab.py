"""
6.101 Lab:
Symbolic Algebra
"""

import doctest

# NO ADDITIONAL IMPORTS ALLOWED!
# You are welcome to modify the classes below, as well as to implement new
# classes and helper functions as necessary.

def expression(inp):
    """
    Tokenize and parse strings into symbolic expressions.
    """
    tokens = tokenize(inp)
    parsed = parse(tokens)
    return parsed

def tokenize(string):
    """
    Split a string into a list of tokens
    (parentheses, variable names, operands, negative numbers)
    """
    print("string",string)
    tokens = []
    operands = ["+","-","*","/"]
    digits = ["0","1","2","3","4","5","6","7","8","9"]
    index = 0
    while index < len(string):
        char = string[index]
        #print("CHAR IS",char,"TOKENS IS",tokens,"index", index)
        # parentheses
        if char == " ":
            index+=1
            continue
        if char in ("(",")"):
            tokens.append(char)
            #print("tokens",tokens)
            index+=1
        elif char.isalpha():
            # variable names: single alphabet letters
            tokens.append(char)
            index+=1
        # operands
        elif char in operands:
            if string[index+1] == " ":
                tokens.append(char)
                index+=1
            else: # if 2 consecutive operands: (-) is a negative number
                cur_number,index = collect_num(string,index)
                print("cur_number",cur_number,"current index",index)
                tokens.append(cur_number)
        elif char in digits:
            cur_number,index = collect_num(string,index)
            tokens.append(cur_number)
    #print(tokens)
    return tokens

def collect_num(string,cur_index):
    operands = ["+","-","*","/"]
    cur_number = string[cur_index]
    cur_index+=1
    while cur_index < len(string) and string[cur_index] not in ("(",")"," ") and string[cur_index] not in operands:
        # print("char",string[cur_index])
        # print("index",cur_index)
        cur_number+=string[cur_index]
        cur_index+=1
        #print("newchar",string[cur_index])
    #print("final index",cur_index)
    return cur_number,cur_index

def parse(tokens):
    """
    Read tokens list back into valid symbolic algebra expressions.
    """
    def parse_expression(index):
        if tokens[index] == "(": # open parentheses starts binop
            p_expression,p_index = parse_expression(index+1)
            # p_index is the operand
            n_expression,n_index = parse_expression(p_index+1)
                # figure out which binop to construct
            if tokens[p_index] == "+":
                final_exp = Add(p_expression,n_expression)
            elif tokens[p_index] == "-":
                final_exp = Sub(p_expression,n_expression)
            elif tokens[p_index] == "*":
                final_exp = Mul(p_expression,n_expression)
            elif tokens[p_index] == "/":
                final_exp = Div(p_expression,n_expression)
            return final_exp,n_index+1

        # base case: string, int, float --> cast to Var or Num
        try: # assuming thngs are ints and floats
            num_item = float(tokens[index])
            return Num(num_item),index+1
        except ValueError: # if something can't be cast to a float, it's a string/letter
            return Var(tokens[index]),index+1

    parsed_expression, next_index = parse_expression(0)
    return parsed_expression

class Symbol():
    """"
    Overarching parent class to store different types of symbols.
    """
    # operation to do first has highest precedence
    # Num and Var, then Mul and Div, then Add and Subtract
    precedence = 2

    def __add__(self,other):
        return Add(self,other)

    # swap arguments when invoking radd method
    # on a first object that is Not built in python type
    def __radd__(self,other):
        return Add(other,self)

    def __sub__(self,other):
        return Sub(self,other)

    def __rsub__(self,other):
        return Sub(other,self)

    def __mul__(self,other):
        return Mul(self,other)

    def __rmul__(self,other):
        return Mul(other,self)

    def __truediv__(self,other):
        return Div(self,other)

    def __rtruediv__(self,other):
        return Div(other,self)



class BinOp(Symbol):
    """
    Subclass of Symbol to store binary operations.
    """
    def __init__(self,left,right):
        self.left = left
        self.right = right
        if isinstance(self.left,str):
            self.left = Var(self.left)
        elif type(self.left) in (int,float):
            self.left = Num(self.left)

        if isinstance(self.right,str):
            self.right = Var(self.right)
        elif type(self.right) in (int,float):
            self.right = Num(self.right)
        # otherwise type Symbol and we don't have to change type

    def __repr__(self):
        return f"{self.__class__.__name__}({repr(self.left)}, {repr(self.right)})"

    def __str__(self):
        """
        String representation that is human-readable.
        Displays BinOp.
        """
      # self is an Add/Sub/Mul/Div object
        str_left = str(self.left)
        str_right = str(self.right)

        # lower precedence = NOT default expression, so wrap it
        # to make sure you do it first
        if self.left.precedence < self.precedence:
            str_left = f"({str_left})"

        if self.right.precedence < self.precedence:
            str_right = f"({str_right})"

        if (self.wrap_right_at_same_precedence and self.precedence ==
            self.right.precedence):
            str_right = f"({str_right})"

      # if neither left nor right are further expressions
        return f"{str_left} {self.operand} {str_right}"

    def eval(self,mapdict):
        # check left
        left = self.left.eval(mapdict)
        # check right
        right = self.right.eval(mapdict)
        return self.operate(left,right)

    def __eq__(self,other):
        if type(self) != type(other):
            return False
        if self.left == other.left and self.right == other.right:
            # == recursively calls equal
            return True
        return False

class Add(BinOp):
    """
    Binary operation subclass for addition of two symbols.
    """
    operand = "+"
    precedence = 0
    wrap_right_at_same_precedence = False

    def operate(self,left,right):
        return left+right

    def deriv(self,diff): # sum rule
        return Add(self.left.deriv(diff),self.right.deriv(diff))

    def simplify(self):
        """
        Simplify an addition expression by removing zeros
        and combining numbers.
        """
        left = self.left.simplify()
        right = self.right.simplify()
        # if left or right are 0, addition of 0 returns the other
        if left == Num(0):
            #print("LEFT IS",left,"AND RIGHT IS",right)
            return right
        if right == Num(0):
            return left
        if isinstance(left,Num) and isinstance(right,Num):
            return Num(left.n+right.n)
        return Add(left,right)

class Sub(BinOp):
    """
    Binary operation subclass for subtraction of two symbols.
    """
    operand = "-"
    precedence = 0
    wrap_right_at_same_precedence = True

    def operate(self,left,right):
        return left-right

    def deriv(self,diff): # sum rule
        return Sub(self.left.deriv(diff),self.right.deriv(diff))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        # left - right, if right = 0, return left
        if right == Num(0):
            return left
        if isinstance(left,Num) and isinstance(right,Num):
            return Num(left.n-right.n)
        return Sub(left,right)


class Mul(BinOp):
    """
    Binary operation subclass for multiplication of two symbols.
    """
    operand = "*"
    precedence = 1
    wrap_right_at_same_precedence = False

    def operate(self,left,right):
        return left*right

    def deriv(self,diff): # product rule
        ans = Mul(self.left,self.right.deriv(diff)) \
        + Mul(self.right,self.left.deriv(diff))
        return ans

    def simplify(self):
        """
        Simplify multiplication expression.
        """
        left = self.left.simplify()
        right = self.right.simplify()
        # left*right, if left or right are 1, return the other
        if left == Num(0) or right == Num(0):
            return Num(0)
        if left == Num(1):
            return right
        if right == Num(1):
            return left
        if isinstance(left,Num) and isinstance(right,Num):
            return Num(left.n*right.n)
        return Mul(left,right)


class Div(BinOp):
    """
    Binary operation subclass for division of two symbols.
    """
    operand = "/"
    precedence = 1
        # not commutative
    wrap_right_at_same_precedence = True

    def operate(self,left,right):
        return left/right

    def deriv(self,diff): # quotient rule
        first = self.right*self.left.deriv(diff)
        second = self.left*self.right.deriv(diff)
        # use dunders
        return (first-second)/(self.right*self.right)

    def simplify(self):
        """
        Simplify division expression.
        """
        left = self.left.simplify()
        right = self.right.simplify()
        # left/right, if right is 1
        # dividing 0/other
        if left == Num(0):
            return Num(0)
        if right == Num(1):
            return left
        if isinstance(left,Num) and isinstance(right,Num):
            return Num(left.n/right.n)
        return Div(left,right)

class Var(Symbol):
    """
    Subclass of Symbol object to store variable.
    """
    def __init__(self, n):
        """
        Initializer.  Store an instance variable called `name`, containing the
        value passed in to the initializer.
        """
        self.name = n

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"Var('{self.name}')"

    def eval(self,mapdict):
        if self.name not in mapdict:
            raise NameError("variable not in mapdict")
        return mapdict[self.name] # return the value corresponding to variable name
        # where Var("x") has "x" as variable name

    def __eq__(self,other):
        if type(self) != type(other):
            return False
        return self.name == other.name

    def deriv(self,diff):
        # deriv of z w/ respect to x = 0
        if diff != self.name:
            return Num(0)
        # derivative of any Var('x') w/ respect to x = 1
        # coefficients accounted for by product
        return Num(1)

    def simplify(self):
        return Var(self.name)



class Num(Symbol):
    """
    Subclass of Symbol object to store int or float.
    """
    def __init__(self, n):
        """
        Initializer.  Store an instance variable called `n`, containing the
        value passed in to the initializer.
        """
        self.n = n

    def __str__(self):
        return str(self.n)

    def __repr__(self):
        return f"Num({self.n})"

    def eval(self,mapdict):
        return self.n

    def __eq__(self,other):
        if type(self) != type(other):
            return False
        return self.n == other.n

    def deriv(self,diff):
        # derivative for a number = 0
        return Num(0)

    def simplify(self): # call on a num
        return Num(self.n)

if __name__ == "__main__":
    doctest.testmod()
    # result = Add(Num(0), Var("x"))
    # expected = Var("x")
    # result = Div(Num(0), Var("x"))
    # expected = Num(0)
    # result = Add(Num(20), Num(30))
    # expected = Num(50)
    # result = Mul(Add(Num(0), Var("x")), Var("z"))
    # expected = Mul(Var("x"), Var("z"))
    # print(result.simplify())

    tokens = tokenize("(x * (2.3 + -3))")
    exp = ['(', 'x', '*', '(', '2.3', '+', '-3', ')', ')']
    print("expected tokens",exp)
    print("result tokens",tokens)
    print(exp == tokens)
    # tokens = tokenize("(x * (2 + 3))")
    # #print("TOKENIZED VERSION",tokens)
    # parsed = parse(tokens)
    # #exp = Mul(Var('x'), Add(Num(2), Num(3)))
    # print(parsed)
    #print(exp == parsed)
