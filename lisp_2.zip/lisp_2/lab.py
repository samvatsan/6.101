"""
6.101 Lab: Sam Vinu-Srivatsan
LISP Interpreter Part 2
"""

#!/usr/bin/env python3
import sys
sys.setrecursionlimit(20_000)

"""
6.101 Lab: Sam Vinu-Srivatsan
LISP Interpreter Part 1
"""

#!/usr/bin/env python3

import sys

sys.setrecursionlimit(20_000)

# NO ADDITIONAL IMPORTS!

#############################
# Scheme-related Exceptions #
#############################


class SchemeError(Exception):
    """
    A type of exception to be raised if there is an error with a Scheme
    program.  Should never be raised directly; rather, subclasses should be
    raised.
    """

    pass


class SchemeSyntaxError(SchemeError):
    """
    Exception to be raised when trying to evaluate a malformed expression.
    """

    pass


class SchemeNameError(SchemeError):
    """
    Exception to be raised when looking up a name that has not been defined.
    """

    pass


class SchemeEvaluationError(SchemeError):
    """
    Exception to be raised if there is an error during evaluation other than a
    SchemeNameError.
    """

    pass


############################
# Tokenization and Parsing #
############################


def number_or_symbol(value):
    """
    Helper function: given a string, convert it to an integer or a float if
    possible; otherwise, return the string itself

    >>> number_or_symbol('8')
    8
    >>> number_or_symbol('-5.32')
    -5.32
    >>> number_or_symbol('1.2.3.4')
    '1.2.3.4'
    >>> number_or_symbol('x')
    'x'
    """
    try:
        return int(value)
    except ValueError:
        try:
            return float(value)
        except ValueError:
            return value


def tokenize(source):
    """
    Splits an input string into meaningful tokens (left parens, right parens,
    other whitespace-separated values).  Returns a list of strings.

    Arguments:
        source (str): a string containing the source code of a Scheme
                      expression
    """
    tokens = []
    comment = False
    index = 0

    while index < len(source):
        char = source[index]
        if comment == False: # treat normally
            if char == ";": # enter comment
                comment = True
                index+=1
            elif char in (" ","\n"): # no comment
                index+=1
                #continue
            elif char in ("(",")"):
                tokens.append(char)
                index+=1
            else:  # if char is anything else
                atomic,index = collect_num(source,index)
                tokens.append(atomic)
                if index < len(source):
                    char = source[index]
                continue
        else: # if in a comment
            if char == "\n": # escape comment
                comment = False
                index+=1
            else:
                index+=1 # stay in comment, keep increasing indices
    #print(tokens)
    return tokens

def collect_num(string,cur_index):
    atomic = string[cur_index]
    cur_index+=1
    while cur_index < len(string) and string[cur_index] not in ("(",")"," ","\n"):
        # keep collecting you hit a stop character
        atomic+=string[cur_index]
        cur_index+=1
    return atomic,cur_index


# def expression(inp):
#     """
#     Tokenize and parse strings into symbolic expressions.
#     """
#     tokens = tokenize(inp)
#     parsed = parse(tokens)
#     return parsed


def parse(tokens):
    """
    Parses a list of tokens, constructing a representation where:
        * symbols are represented as Python strings
        * numbers are represented as Python ints or floats
        * S-expressions are represented as Python lists

    Arguments:
        tokens (list): a list of strings representing tokens
    """
    def parse_expression(index):
        if tokens[index] not in "()":
            #  base case with number/symbol hwere character is inside an expression
            val_type = number_or_symbol(tokens[index])
            return val_type,index+1
        elif tokens[index] == "(":
            sublist = []
            if len(tokens) > 1:
                index+=1
            else:
                raise SchemeSyntaxError("parse syntax error")
            while tokens[index] != ")":
                exp,ind = parse_expression(index)
                sublist.append(exp)
                index=ind
                if index >= len(tokens):
                    raise SchemeSyntaxError("parse syntax error")
            return sublist,index+1
        else:
            raise SchemeSyntaxError("malformed expression")
    parsed_expression, next_index = parse_expression(0)

    if len(tokens) > next_index:
        # there are things after final closed parens
        raise SchemeSyntaxError("malformed expression")
    return parsed_expression


######################
# Built-in Functions #
######################


def multiply(args):
    """ multiply  all args list elements. """
    product = 1
    for arg in args:
        product*=arg
    return product

def divide(args):
    """ divide all args list elements. """
    div = args[0]
    for i in range(1,len(args)):
        div/=args[i]
    return div

def equal(args):
    """ check for equality of all elts """
    checker = args[0]
    for arg in args:
        if arg != checker:
            return False
    return True

def decreasing(args):
    """ check for decreasing order sort """
    previous = args[0]
    for i in range(1,len(args)):
        if not previous > args[i]:
            return False
        previous = args[i] # reset
    return True

def nonincreasing(args):
    """check for geq order sort """
    previous = args[0]
    for i in range(1,len(args)):
        if not previous >= args[i]:
            return False
        previous = args[i] # reset
    return True

def increasing(args):
    """check for increasing order sort"""
    previous = args[0]
    for i in range(1,len(args)):
        if not previous < args[i]:
            return False
        previous = args[i] # reset
    return True

def nondecreasing(args):
    """inclusiv econdition, leq sort"""
    previous = args[0]
    for i in range(1,len(args)):
        if not previous <= args[i]:
            return False
        previous = args[i] # reset
    return True

def negate(args):
    """not condition for boolean expr"""
    if len(args) != 1:
        raise SchemeEvaluationError("wrong # params for not")
    if args[0] not in (True,False): # must be Boolean
        raise SchemeEvaluationError("not only takes Booleans")
    return not args[0]

def car(args): # acceptable formats of args: [Pair], Pair
    """get first part of pair object """
    if isinstance(args,list):
        if len(args) != 1 or not isinstance(args[0],Pair):
            raise SchemeEvaluationError("can't find pair inside lise")
        cell = args[0]

    elif isinstance(args,Pair):
        cell = args

    else:
        raise SchemeEvaluationError("unsupported type")

    return cell.car

def cdr(args):
    """get second part of pair object"""
    if isinstance(args,list):
        if len(args) != 1 or not isinstance(args[0],Pair):
            raise SchemeEvaluationError("can't find pair inside lise")
        cell = args[0]

    elif isinstance(args,Pair):
        cell = args

    else:
        raise SchemeEvaluationError("unsupported type")

    return cell.cdr


def linkedlist(args):
    """make a linked scheme list"""
    if len(args) == 0:
        return "()"
    if len(args) == 1: # last elt
        return Pair(args[0],"()")
    return Pair(args[0],linkedlist(args[1:]))

def checklist(args):
    """check if something is really a list"""
    item = args
    if isinstance(args,list):
        if len(args) != 1:
            raise SchemeEvaluationError("wrong # arguments to checklist")
        item = args[0] # if it's a list
    return islist(item)

def islist(sublist):
    """recursive helper for checklist"""
    if sublist == "()": # empty list
        return True
    # nonempty list: Pair, cdr is Pair or empty
    if isinstance(sublist,Pair):
        return islist(cdr(sublist))
    return False

def length(args): # args is a list
    """recursively get length of a list"""
    if isinstance(args,list):
        if len(args) != 1:
            raise SchemeEvaluationError("wrong # of params for length")

    def helper(inp): # inp Pair
        """helper for lenth"""
        if inp == "()":
            return 0
        if not isinstance(inp,Pair):
            raise SchemeEvaluationError("not a list")
        return 1 + helper(cdr(inp))

    return helper(args[0]) # add 1 more for the last car

def ref(args):
    """index into a scheme linked list"""
    if isinstance(args,list):
        if len(args) != 2:
            raise SchemeEvaluationError("need exactly 2 params")
    item = args[0]
    index = args[1]
    if not isinstance(item,Pair):
        raise SchemeEvaluationError("ref needs a pair object")
    # check if cons or list
    if index == 0:
        return car(item)
    # if index is not 1
    if not checklist(cdr(item)): # if cdr is not also a cons
        raise SchemeEvaluationError("cdr also needs to be a cons cell")

    def index_helper(link,cur_index): # count from 0 until you hit index
        """helper for index recursing"""
        if cur_index == index:
            return car(link)
        return index_helper(cdr(link),cur_index+1)

    return index_helper(item,0)



def append(args): # args is a list of scheme lists to append
    """
    append or concatenate multiple lists
    using a first/rest method
    """
    # base case
    if len(args) == 0:
        return "()"
    # skip case
    if args[0] == "()":
       return append(args[1:])
    # recurse case
    new_list = [cdr(args[0])] + args[1:]
    return Pair(car(args[0]),append(new_list))


# def shallow_copy(item):
#     if cdr(item) == "()":
#         return Pair(car(item),cdr(item))
#     return Pair(car(item),shallow_copy(cdr(item)))


def construct(args): # [a b]
    """
    create a cons cell pair object
    """
    if len(args) != 2:
        raise SchemeEvaluationError("wrong # params to construct")
    return Pair(args[0],args[1])

def begin(args):
    """
    string together multiple scheme expressions
    or lines to evaluate together.
    helps run one program fully
    """
    # takes in a list of expressions to evaluate
    # latest = args[0]
    # for line in args:
    #     print("line in args IS",line)
    #     latest = evaluate(line,frame) # already a function
    #     print("evaluated line IS",line) # now latest is last line evaluated
    # return latest

    # # are they all evaluated already bc special form
    return args[-1]

scheme_builtins = {
    "+": sum,
    "-": lambda args: -args[0] if len(args) == 1 else (args[0] - sum(args[1:])),
    "*": multiply,
    "/": divide,
    "equal?": equal,
    ">": decreasing, # could put all 4 comparisons geq/leq in 1 fcn
    ">=": nonincreasing,
    "<": increasing,
    "<=": nondecreasing,
    "#t": True,
    "#f": False,
    "cons": construct,
    "car": car,
    "cdr": cdr,
    "[]": "()", # create empty tuple - immutable
    "list": linkedlist,
    "list?": checklist,
    "length": length,
    "not": negate,
    "list-ref":ref,
    "begin":begin,
    "append":append
}

##############
# Evaluation #
##############

def evaluate(tree,frame=None):
    """
    Evaluate the given syntax tree according to the rules of the Scheme
    language.

    Arguments:
        tree (type varies): a fully parsed expression, as the output from the
                            parse function
    """
    #print("the thing that is being evaluated: ",tree)
    if frame is None:
        frame = make_initial_frame() # new empty frame

    if not isinstance(tree,list):
        val = number_or_symbol(str(tree))
        if type(val) in (float,int):
            return val
        else: # if string
            return frame[val] # inherits from scheme_builtins
    # recursive case: tree is a list

    if len(tree) == 0:
        return "()" # return your representation

    # SPECIAL FORMS
    if tree[0] == "define":
        if not isinstance(tree[1],list):
            # EXPLICIT CASE
            # assuming 2 elements: name, expr
            name = tree[1]
            expr = evaluate(tree[2],frame)
            frame.set_value(name,expr)
            return expr
        else: # if elt 1 is S-list
            # IMPLICIT CASE
            name_vars = tree[1] # list
            name = name_vars[0]
            vars = name_vars[1:]
            body = tree[2]
            # create a new lambda object
            func = Function(vars,body,frame)
            frame.set_value(name,func)
            return func

    elif tree[0] == "lambda": # [funcname,[args],[body]]
        # built in function
        args = tree[1]
        body = tree[2]
        func = Function(args,body,frame)
        return func
    # DOES RECURSION take care of functions wrapped in () to return the result of evaluating them

    elif tree[0] == "and":
        for arg in tree[1:]:
            if not evaluate(arg,frame): # if 1 is False
                return False
        return True # all args evaluate to True

    elif tree[0] == "or":
        for arg in tree[1:]:
            if evaluate(arg,frame): # if 1 is True
                return True
        return False # no True values

    elif tree[0] == "if": # (if PRED TRUE_EXP FALSE_EXP)
        # scheme eval error? for weird size
        if len(tree) != 4:
            raise SchemeEvaluationError("too many arguments in if statement")
        if evaluate(tree[1],frame): # if it's True
            return evaluate(tree[2],frame)
        else: # only evaluate 1 branch
            return evaluate(tree[3],frame)

    elif tree[0] == "del":
        var = tree[1]
        if var in frame.vals:
            val = frame.vals[var]
            del frame.vals[var]
            return val
        else:
            raise SchemeNameError

    elif tree[0] == "let": # [[var1 val1],[var2=val2]], body
        newframe = Frame(frame)
        for binding in tree[1]: # tree[1] is a list of bindings
            val = evaluate(binding[1],frame) # evaluate in this frame
            newframe.set_value(binding[0],val) # bind in new frame
        return evaluate(tree[2],newframe) # evaluating body in new frame

    elif tree[0] == "set!":
        # tree[1] = var, tree[2] = expr
        result = evaluate(tree[2],frame)
        frame.rebind_enclosing(tree[1],result)
        return result


    # NONSPECIAL FORMS
    iter = [] # ['append']
    for nested in tree:
        iter.append(evaluate(nested,frame))

    if callable(iter[0]):
        func = iter[0]
        return func(iter[1:])
    else:
        print("iter[0] is ",iter[0])
        raise SchemeEvaluationError("first element in S-expression not function")


class Function:
    """
    create a function class for scheme functions
    """
    def __init__(self,params,body,frame):
        """
        initialize functions
        """
        self.params = params
        self.body = body
        self.frame = frame

    def __call__(self,evaluated_args):
        """
        be able to call functions
        """
        # map the parameters to the arguments
        child_frame = Frame(self.frame)
        # check length before looping through to map
        if len(self.params) != len(evaluated_args):
            raise SchemeEvaluationError("error in function call")
        for index in range(len(evaluated_args)):
            child_frame.set_value(self.params[index],evaluated_args[index])
        # execute the body
        return evaluate(self.body,child_frame)

        # self.frame is enclosing (where a function is defined)
        # cur_frame is where the function is called
        # child_frame is what gets created to evaluate the function call

class Frame:
    """
    create a frame class to have different levels of bindings
    for scheme variables and expressions
      """
    def __init__(self,parent):
        """
        initialize a frame object
        ith a parent and map
        """
        # instance attribute because variables will be different for every frame
        self.vals = {} # map names to expression values
        self.parent = parent

    def __getitem__(self,name):
        """
        get a value with a name
        from a frame binding
        """
        if name in self.vals:
            return self.vals[name]
        elif self.parent is None:
            raise SchemeNameError("can't find item in frame or any parents")
        else: # search recursively
            return self.parent[name]

    def set_value(self,name,expr):
        """"
        bind name = expr in current frame self
        """
        self.vals[name] = expr

    def rebind_enclosing(self,var,expr):
        """
        recursively find enclosing frame
        of var and rebind to new expr
        """
        if var in self.vals:
            self.vals[var] = expr
        elif self.parent is None:
            raise SchemeNameError("can't find item in frame or any parents")
        else: # search recursively
            self.parent.rebind_enclosing(var,expr)


def make_initial_frame():
    """
    make a new global frame
    for evaluate
    """
    frame = Frame(None)
    for key in scheme_builtins:
        frame.vals[key] = scheme_builtins[key]
    newframe = Frame(frame)
    return newframe

class Pair:
    """
    representation of cons cell object
    """
    def __init__(self,car,cdr):
        """
        initialize with first and second parts
        """
        self.car = car
        self.cdr = cdr

    def __str__(self):
        return f"({self.car},{self.cdr})"

    def set_cdr(self,value):
        self.cdr = value

    def get_car(self):
        return self.car

def evaluate_file(filename,frame=None):
    """
    open and evaluate the scheme
    code in a file
    """
    f = open(filename, "r")
    scheme = parse(tokenize(f.read()))
    #print("scheme code is",scheme)
    return evaluate(scheme,frame)


if __name__ == "__main__":
    # NOTE THERE HAVE BEEN CHANGES TO THE REPL, KEEP THIS CODE BLOCK AS WELL
    # code in this block will only be executed if lab.py is the main file being
    # run (not when this module is imported)

    # token = "(if (list? (append)) 1 0)"
    # input = parse(tokenize(token))
    # print(input)
    # print(evaluate(input))
    # #print(type(evaluate(parse(tokenize("()")))))
    # f = evaluate_file("/Users/samvinu/Downloads/MIT/S24/6.101/lisp_2/test_files/small_test1.scm")
    # print(f)

    files = sys.argv[1:]
    myframe = make_initial_frame()
    for file in files:
        print(evaluate_file(file,myframe))

    import os
    sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
    import schemerepl
    schemerepl.SchemeREPL(sys.modules[__name__], use_frames=True, verbose=True, global_frame=myframe).cmdloop()
